<html>
<head>
	<title>Ejemplos de ABM - con archivo de texto</title>
	  
		<?php require_once"partes/referencias.php" ;/**/?>
		<!--final de Estilos-->    

      <script type="text/javascript" src="./bower_components/jquery/dist/jquery.js"></script>
       
</head>
<body>
	<?php		
		require_once"partes/barraDeMenu.php";
	 ?>
	  <div class="container">

	  	  <div class="page-header " >
                <h1>ABM - con archivo de texto Versión 1.0.2 Con foto</h1>      
            </div>
					<div class="CajaInicio animated bounceInRight">
							<h1>PERSONAS</h1>
						
							<form id="FormIngreso">
 										
									    <a href="formAlta.php" class="list-group-item  list-group-item list-group-item-info">
									      <h4 class="list-group-item-heading">Alta de Personas</h4>
									    </a>
										
										<a href="formGrilla.php" class="list-group-item  list-group-item list-group-item-info">
									      <h4 class="list-group-item-heading">Grilla de Personas</h4>
									    </a>
									
									  </div>
									
							</form>
						</div>
		</div>
</body>
</html>