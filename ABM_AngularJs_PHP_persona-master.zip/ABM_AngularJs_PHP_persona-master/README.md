# ABM_AngularJs_PHP_persona


Ejemplo de la carga de datos usando Angularjs y PHP
