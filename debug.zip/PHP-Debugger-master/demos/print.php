<?php
include( dirname(dirname(__FILE__))  . '/src/Debug.php' );
//Print server variables
Debug::printData( $_SERVER );
?>
